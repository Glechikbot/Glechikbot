import logging
import os
import time
import telebot
from datetime import datetime

# Ініціалізація логера
logging.basicConfig(level=logging.INFO)

# Токен з environment змінної
TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

# ID користувача (можна буде вставити свій)
USER_ID = int(os.getenv("USER_ID"))

# Повідомлення
morning_messages = [
    "🎯 День 1
Добрий ранок, додіку. Ніяких рілсів! Прокинувся — зроби щось корисне!",
    "🎯 День 2
Ну що, сонна глечина, вже встав? Час стати мутантом продуктивності.",
    "🎯 День 3
Життя коротке — не витрачай його на тикання в меми.",
    "🎯 День 4
Сьогодні ти або прокидаєшся, або тебе прокидає Глечик… кулаком.",
    "🎯 День 5
Не Reels, а реальність. Не телефон — а дії. Поняв?",
    "🎯 День 6
Ти не втомлений — ти просто ще не в режимі звіра. Увімкнись.",
    "🎯 День 7
Прокидайся як герой. Або принаймні як людина, а не мікрохвильовка."
]

evening_messages = [
    "🌙 Вечір 1
Підсумки дня? Що зробив, окрім прокрастинації та чаю з мемами?",
    "🌙 Вечір 2
Запиши хоч одну думку дня. Навіть якщо це «я існую».",
    "🌙 Вечір 3
Час на сон. Не в TikTok. В ліжко. Прямо зараз.",
    "🌙 Вечір 4
Закрий очі. Ти зробив що зміг. Завтра — новий удар.",
    "🌙 Вечір 5
Випиши 1 ідею. Навіть дурну. Може, вона стане мільйонною.",
    "🌙 Вечір 6
Що б ти сказав собі з майбутнього? Пора сказати це зараз.",
    "🌙 Вечір 7
Твій мозок дякує. Він хоче сну, а не ще один Reels."
]

def send_daily_messages():
    day = (datetime.utcnow().date() - datetime(2025, 5, 16).date()).days % 7
    hour = datetime.utcnow().hour

    try:
        if hour == 5:  # 8:00 по Києву = 5:00 UTC
            bot.send_message(USER_ID, morning_messages[day])
        elif hour == 21:  # 00:00 по Києву = 21:00 UTC
            bot.send_message(USER_ID, evening_messages[day])
    except Exception as e:
        logging.error(f"Помилка надсилання повідомлення: {e}")

# Цикл
while True:
    send_daily_messages()
    time.sleep(3600)