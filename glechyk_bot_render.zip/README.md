# GlechykBot — антидофаміновий бот на кожен день

1. Створи Telegram-бота через @BotFather
2. Отримай токен і свій Telegram user ID (можна з BotInfoBot)
3. Заливай на Render як Background Worker
4. Додай environment variables:
   - `BOT_TOKEN`: токен з BotFather
   - `USER_ID`: свій Telegram ID